﻿using System;

namespace LogSys.Aplication
{
	public class Class1
	{
	}
}
