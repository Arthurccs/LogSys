﻿using Microsoft.AspNetCore.Mvc;


namespace LogSys.WepApi.Controllers
{
	[ApiController]
	[Route("api")]
	public class BaseApiController : ControllerBase
	{
	}
}
